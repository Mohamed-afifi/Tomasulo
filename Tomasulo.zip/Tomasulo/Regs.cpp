#include "Regs.h"
Regs Regs::instance;
Regs::Regs()
{
	for (int i = 0; i < 8; i++)
		regs[i] = 0;
}


void Regs::setValue(int regNum, int value)
{
	if (regNum == 0)
		return;

	regs[regNum] = value;
}

int Regs::getValue(int regNum)
{
	return regs[regNum];
}