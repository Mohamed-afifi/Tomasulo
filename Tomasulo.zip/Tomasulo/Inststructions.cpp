#include "Inststructions.h"
#include "Regs.h"

void Inststructions::setDataMemory(DataMemory* dataMem)
{
    this->dataMem = dataMem;
}

void Inststructions::SetType(string ty)
{
    type = ty;
}

void Inststructions::set_offset(int off)
{
    if (off < -64 || off>63)
    {
        cout << "Sorry there was a problem reading the offset. Please try again.\n";
        exit(0);
    }
    offset = off;
}

void Inststructions::setR1(int str)
{
    Rg1 = str;

}

void Inststructions::setR2(int str)
{
    Rg2 = str;
}

void Inststructions::setR3(int str)
{
    Rg3 = str;
}

int Inststructions::getRg1()
{
    return Rg1;
}

int Inststructions::getRg2()
{
    return Rg2;
}

int Inststructions::getRg3()
{
    return Rg3;
}

int Inststructions::getoffset()
{
    return offset;
}

string Inststructions::getType()
{
    return type;
}

void Inststructions::load()
{
    int out = Regs::get().getValue(Rg1) + offset;
    Regs::get().setValue(Rg3, out);
}

void Inststructions::store()
{
    int out = Regs::get().getValue(Rg1) + offset;
    //Regs::
}

void Inststructions::beq()
{
}

void Inststructions::JAL_RET()
{
}

void Inststructions::Add()
{
}

void Inststructions::neg()
{
}

void Inststructions::NOR()
{
}

void Inststructions::MULT()
{
}

void Inststructions::SetAddr(int addr)
{
    this->addr = addr;
}

