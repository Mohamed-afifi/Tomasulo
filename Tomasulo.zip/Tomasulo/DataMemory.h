#pragma once
class DataMemory
{
	int arr[1024];
public:
	DataMemory();
	int GetEntry(int addr);
	void AddEntry(int addr, int value);
	void PrintContent();
};

