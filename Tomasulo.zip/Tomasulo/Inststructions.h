#pragma once
#include<iostream>
#include"DataMemory.h"
using namespace std;
class Inststructions
{
private:
	string type;
	// Rg1 & Rg2 & Rg3 are indicies to the values inside the Regs
	int Rg1, Rg2, Rg3;  // Rg3 is output or the storing of the result
	int offset;			// Same as the immediate
	int addr;
	// Reference to the datamemory
	DataMemory* dataMem;
public:
	void setDataMemory(DataMemory* dataMem);
	void SetType(string ty);
	void set_offset(int off);
	void setR1(int);
	void setR2(int);
	void setR3(int);
	int getRg1();
	int getRg2();
	int getRg3();
	int getoffset();
	string getType();
	void load();
	void store();
	void beq();
	void JAL_RET();
	void Add();
	void neg();
	void NOR();
	void MULT();
	void SetAddr(int addr);
};

