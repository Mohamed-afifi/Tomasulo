#include "InstructionMemory.h"

void InstructionMemory::AddEntry(Inststructions inst)
{
	arr[count] = inst;
	arr[count].SetAddr(count);
	count++;
}
