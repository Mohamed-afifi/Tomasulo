#pragma once

#include"Inststructions.h"

class InstructionMemory
{
private:
	Inststructions arr[1024];
	int count = 0;

public:
	InstructionMemory() {
	}

	void AddEntry(Inststructions inst);

	Inststructions GetEntry(int addr) {
		return arr[addr];
	}
};

