#pragma once

class Regs
{
private:
	static Regs instance;
	int regs[8];
	Regs();
public:
	static Regs get()
	{
		return instance;
	}
	void setValue(int, int);
	int getValue(int);
};

