#include "DataMemory.h"
#include<iostream>

using namespace std;

DataMemory::DataMemory()
{
	for (int i = 0; i < 1024; i++)
		arr[i] = INT_MAX;
}

int DataMemory::GetEntry(int addr) {
	if (arr[addr] == INT_MAX)
		arr[addr] = 0;
	return arr[addr];
}

void DataMemory::AddEntry(int addr, int value)
{
	arr[addr] = value;
}

void DataMemory::PrintContent()
{
	for (int i = 0; i < 1024; i++)
	{
		if (arr[i] != INT_MAX)
			cout << i << ": " << arr[i] << endl;
	}
}