#include<iostream>

#include "InstructionMemory.h"
#include "Inststructions.h"
#include "Regs.h"

using namespace std;

void parse(Inststructions &obj,string T);

int main()
{
	DataMemory* dataMemory = new DataMemory;
	InstructionMemory* instructionMemory = new InstructionMemory;
	
	Inststructions obj;
	string T = "JAL 56";
	//"BEQ R2, R5, 3";
	parse(obj, T);
	obj.setDataMemory(dataMemory);
	instructionMemory->AddEntry(obj);

	cout << "Type: " << obj.getType() << endl;
	cout << "Rg3: " << obj.getRg3() << endl;
	cout << "Rg1: " << obj.getRg1() << endl;
	cout << "Rg2: " << obj.getRg2() << endl;
	cout << "Offset: " << obj.getoffset() << endl;

	delete dataMemory;
	delete instructionMemory;
}

void parse(Inststructions &obj,string T)
{
	char type[100]{};
	int r1 = 0, r2 = 0, r3 = 0;
	int offset=0;

	string obj_type;
	// Index of the first space tells you when the instruction name is finished
	int space_index = T.find(" ");
	
	// Object type is the substring from 0 to the first space
	obj_type=T.substr(0, space_index);
	obj.SetType(obj_type);

	// LOAD RA,3(RB)
	// You can simply skip the characters you do not need and take what you need
	if (obj_type == "LOAD")
	{
		sscanf_s(T.c_str(), "LOAD R%d, %d(R%d)", &r3, &offset, &r1);
	}
	else if (obj_type == "STORE")
	{
		sscanf_s(T.c_str(), "STORE R%d, %d(R%d)", &r3, &offset, &r1);
	}
	else if (obj_type == "ADD")
	{
		sscanf_s(T.c_str(), "ADD R%d, R%d, R%d", &r3, &r1, &r2);
	}
	else if (obj_type == "BEQ")
	{
		sscanf_s(T.c_str(), "BEQ R%d, R%d, %d", &r3, &r1, &offset); //BEQ R1, R2, offset
	}
	else if (obj_type == "JAL")
	{
		sscanf_s(T.c_str(), "JAL %d",&offset); //BEQ R1, R2, offset
	}
	else if (obj_type == "RET")
	{
		;
	}
	else if (obj_type == "ADDI")
	{
		sscanf_s(T.c_str(), "ADDI R%d, R%d, R%d", &r3, &r1, &r2);

	}
	else if (obj_type == "NEG")
	{
		sscanf_s(T.c_str(), "NEG R%d, R%d", &r3, &r1);

	}
	else if (obj_type == "NOR")
	{
		sscanf_s(T.c_str(), "NOR R%d, R%d, R%d", &r3, &r1, &r2);

	}
	else if (obj_type == "MUL")
	{
		sscanf_s(T.c_str(), "MUL R%d, R%d, R%d", &r3, &r1, &r2);

	}
	obj.SetType(obj_type);
	obj.setR1(r1);
	obj.setR2(r2);
	obj.setR3(r3);
	obj.set_offset(offset);
}
